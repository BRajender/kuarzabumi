import React from "react";
//Layout
import MainLayout from "../layouts/MainLayout";

function AboutUS(props) {
  return (
    <MainLayout>
      <div>
        <h1>About us page</h1>
      </div>
    </MainLayout>
  );
}
export default AboutUS;
