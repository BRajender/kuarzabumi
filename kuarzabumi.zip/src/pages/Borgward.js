import React from "react";
//Layout
import MainLayout from "../layouts/MainLayout";

function Borgward(props){
    return(
        <MainLayout>
      <h1>Borgward page</h1>
    </MainLayout>
    )

}
export default Borgward;