import React from "react";
//Layout
import MainLayout from "../layouts/MainLayout";

function ContactUS(props){
    return(
        <MainLayout>
      <h1>contact us page</h1>
    </MainLayout>
    )

}
export default ContactUS;