import React from "react";
//Layout
import MainLayout from "../layouts/MainLayout";

function GoAuto(props){
    return(
        <MainLayout>
      <h1>Goauto page</h1>
    </MainLayout>
    )

}
export default GoAuto;