import React from "react";
//Layout
import MainLayout from "../layouts/MainLayout";

function LoanCalculator(props){
    return(
        <MainLayout>
      <h1>LoanCalculator page</h1>
    </MainLayout>
    )

}
export default LoanCalculator;