import React from "react";
//Layout
import MainLayout from "../layouts/MainLayout";

function Activity(props){
    return(
        <MainLayout>
      <h1>Activity page</h1>
    </MainLayout>
    )

}
export default Activity;